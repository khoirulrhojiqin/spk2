-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for spk
CREATE DATABASE IF NOT EXISTS `spk` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `spk`;

-- Dumping structure for table spk.m_berkas
CREATE TABLE IF NOT EXISTS `m_berkas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `transkrip` text,
  `sertifikat` text,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_berkas: ~3 rows (approximately)
/*!40000 ALTER TABLE `m_berkas` DISABLE KEYS */;
INSERT INTO `m_berkas` (`id`, `id_user`, `transkrip`, `sertifikat`) VALUES
	(1, 10, '1648481429_8f85b33f6cb28fb87cf1.pdf', '1648481429_1b6ba3d9b78bc2c908a7.pdf'),
	(2, 12, '1655091212_c8e5bf6419c73d44f9aa.pdf', '1655091212_47780ea173bc460e19b6.pdf'),
	(3, 14, '1655101214_5913c490dcac4addbc5f.pdf', '1655101214_4d147ecc89a91afdbbeb.pdf');
/*!40000 ALTER TABLE `m_berkas` ENABLE KEYS */;

-- Dumping structure for table spk.m_log
CREATE TABLE IF NOT EXISTS `m_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_user` varchar(50) DEFAULT NULL,
  `log_tipe` int(2) DEFAULT NULL,
  `log_desc` varchar(50) DEFAULT NULL,
  `log_browser` varchar(50) DEFAULT NULL,
  `log_os` varchar(50) DEFAULT NULL,
  `log_ip` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_log: ~27 rows (approximately)
/*!40000 ALTER TABLE `m_log` DISABLE KEYS */;
INSERT INTO `m_log` (`id`, `log_user`, `log_tipe`, `log_desc`, `log_browser`, `log_os`, `log_ip`) VALUES
	(1, 'aku', 1, 'Logout user', 'Chrome 99.0.4844.51', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(2, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.51', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(3, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(4, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(5, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(6, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(7, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(8, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(9, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(10, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(11, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(12, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(13, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(14, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(15, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(16, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(17, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(18, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(19, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(20, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(21, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(22, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(23, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(24, 'Nur Rezky Rahmani', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(25, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(26, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(27, 'hoirul r', 0, 'Login user', 'Chrome 102.0.5005.63', 'Windows 10', '127.0.0.1:127.0.0.1');
/*!40000 ALTER TABLE `m_log` ENABLE KEYS */;

-- Dumping structure for table spk.m_pm_alternatif
CREATE TABLE IF NOT EXISTS `m_pm_alternatif` (
  `id_alternatif` int(11) NOT NULL AUTO_INCREMENT,
  `alternatif` varchar(50) DEFAULT NULL,
  `k1` int(2) DEFAULT NULL,
  `k2` int(2) DEFAULT NULL,
  `k3` int(2) DEFAULT NULL,
  `k4` int(2) DEFAULT NULL,
  `k5` int(2) DEFAULT NULL,
  `k6` int(2) DEFAULT NULL,
  `k7` int(2) DEFAULT NULL,
  `k8` int(2) DEFAULT NULL,
  `k9` int(2) DEFAULT NULL,
  `k10` int(2) DEFAULT NULL,
  `k11` int(2) DEFAULT NULL,
  `k12` int(2) DEFAULT NULL,
  `ket` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id_alternatif`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_pm_alternatif: ~4 rows (approximately)
/*!40000 ALTER TABLE `m_pm_alternatif` DISABLE KEYS */;
INSERT INTO `m_pm_alternatif` (`id_alternatif`, `alternatif`, `k1`, `k2`, `k3`, `k4`, `k5`, `k6`, `k7`, `k8`, `k9`, `k10`, `k11`, `k12`, `ket`) VALUES
	(1, 'Andi Miftahul Ilmi Fadillah', 2, 5, 3, 5, 2, 4, 5, 4, 5, 4, 2, 3, NULL),
	(2, 'Sahrani', 3, 5, 3, 5, 4, 4, 5, 3, 4, 4, 5, 2, NULL),
	(3, 'Ita Cahyani', 4, 4, 3, 5, 3, 2, 3, 2, 2, 3, 5, 2, NULL),
	(4, 'Ahmad Asyraf', 5, 4, 3, 5, 2, 2, 5, 5, 2, 3, 2, 4, NULL);
/*!40000 ALTER TABLE `m_pm_alternatif` ENABLE KEYS */;

-- Dumping structure for table spk.m_pm_alternatif_copy
CREATE TABLE IF NOT EXISTS `m_pm_alternatif_copy` (
  `id_alternatif` int(11) NOT NULL AUTO_INCREMENT,
  `alternatif` varchar(50) DEFAULT NULL,
  `k1` int(2) DEFAULT NULL,
  `k2` int(2) DEFAULT NULL,
  `k3` int(2) DEFAULT NULL,
  `k4` int(2) DEFAULT NULL,
  `k5` int(2) DEFAULT NULL,
  `k6` int(2) DEFAULT NULL,
  `k7` int(2) DEFAULT NULL,
  `k8` int(2) DEFAULT NULL,
  `k9` int(2) DEFAULT NULL,
  `k10` int(2) DEFAULT NULL,
  `k11` int(2) DEFAULT NULL,
  `k12` int(2) DEFAULT NULL,
  `ket` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id_alternatif`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table spk.m_pm_alternatif_copy: ~4 rows (approximately)
/*!40000 ALTER TABLE `m_pm_alternatif_copy` DISABLE KEYS */;
INSERT INTO `m_pm_alternatif_copy` (`id_alternatif`, `alternatif`, `k1`, `k2`, `k3`, `k4`, `k5`, `k6`, `k7`, `k8`, `k9`, `k10`, `k11`, `k12`, `ket`) VALUES
	(3, 'Andi Miftahul Ilmi Fadillah', 2, 5, 3, 5, 2, 4, 5, 4, 5, 4, 2, 3, NULL),
	(4, 'Sahrani', 3, 5, 3, 5, 4, 4, 5, 3, 4, 4, 5, 2, NULL),
	(5, 'Ita Cahyani', 4, 4, 3, 5, 3, 2, 3, 2, 2, 3, 5, 2, NULL),
	(6, 'Ahmad Asyraf', 5, 4, 3, 5, 2, 2, 5, 5, 2, 3, 2, 4, NULL);
/*!40000 ALTER TABLE `m_pm_alternatif_copy` ENABLE KEYS */;

-- Dumping structure for table spk.m_pm_cf_sf_temporary
CREATE TABLE IF NOT EXISTS `m_pm_cf_sf_temporary` (
  `id_alternatif` int(11) NOT NULL AUTO_INCREMENT,
  `alternatif` varchar(50) DEFAULT NULL,
  `administrasi_cf` float DEFAULT NULL,
  `administrasi_sf` float DEFAULT NULL,
  `kompetensi_cf` float DEFAULT NULL,
  `kompetensi_sf` float DEFAULT NULL,
  `mengajar_cf` float DEFAULT NULL,
  `mengajar_sf` float DEFAULT NULL,
  `wawancara_cf` float DEFAULT NULL,
  `wawancara_sf` float DEFAULT NULL,
  PRIMARY KEY (`id_alternatif`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table spk.m_pm_cf_sf_temporary: ~4 rows (approximately)
/*!40000 ALTER TABLE `m_pm_cf_sf_temporary` DISABLE KEYS */;
INSERT INTO `m_pm_cf_sf_temporary` (`id_alternatif`, `alternatif`, `administrasi_cf`, `administrasi_sf`, `kompetensi_cf`, `kompetensi_sf`, `mengajar_cf`, `mengajar_sf`, `wawancara_cf`, `wawancara_sf`) VALUES
	(1, 'Andi Miftahul Ilmi Fadillah', 4.3, 5, 6.5, 4.5, 9.8, 3.5, 2, 5),
	(2, 'Sahrani', 5.3, 5, 7.5, 4.5, 9.8, 3.5, 5, 4),
	(3, 'Ita Cahyani', 6.5, 5, 7, 4, 8, 5, 5, 4),
	(4, 'Ahmad Asyraf', 7.5, 5, 6.5, 4, 9.5, 3.5, 2, 4.5);
/*!40000 ALTER TABLE `m_pm_cf_sf_temporary` ENABLE KEYS */;

-- Dumping structure for table spk.m_pm_gap_temporary
CREATE TABLE IF NOT EXISTS `m_pm_gap_temporary` (
  `id_alternatif` int(11) NOT NULL AUTO_INCREMENT,
  `alternatif` varchar(50) DEFAULT NULL,
  `k1` float DEFAULT NULL,
  `k2` float DEFAULT NULL,
  `k3` float DEFAULT NULL,
  `k4` float DEFAULT NULL,
  `k5` float DEFAULT NULL,
  `k6` float DEFAULT NULL,
  `k7` float DEFAULT NULL,
  `k8` float DEFAULT NULL,
  `k9` float DEFAULT NULL,
  `k10` float DEFAULT NULL,
  `k11` float DEFAULT NULL,
  `k12` float DEFAULT NULL,
  `ket` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id_alternatif`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table spk.m_pm_gap_temporary: ~4 rows (approximately)
/*!40000 ALTER TABLE `m_pm_gap_temporary` DISABLE KEYS */;
INSERT INTO `m_pm_gap_temporary` (`id_alternatif`, `alternatif`, `k1`, `k2`, `k3`, `k4`, `k5`, `k6`, `k7`, `k8`, `k9`, `k10`, `k11`, `k12`, `ket`) VALUES
	(1, 'Andi Miftahul Ilmi Fadillah', 2, 4.5, 5, 5, 3, 4.5, 3.5, 5, 3.5, 4, 2, 5, NULL),
	(2, 'Sahrani', 3, 4.5, 5, 5, 5, 4.5, 3.5, 4, 4.5, 4, 5, 4, NULL),
	(3, 'Ita Cahyani', 4, 5, 5, 5, 4, 4, 5, 3, 4, 3, 5, 4, NULL),
	(4, 'Ahmad Asyraf', 5, 5, 5, 5, 3, 4, 3.5, 4.5, 4, 3, 2, 4.5, NULL);
/*!40000 ALTER TABLE `m_pm_gap_temporary` ENABLE KEYS */;

-- Dumping structure for table spk.m_pm_kriteria
CREATE TABLE IF NOT EXISTS `m_pm_kriteria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(10) DEFAULT NULL,
  `kriteria` varchar(20) DEFAULT NULL,
  `bobot` int(2) DEFAULT NULL,
  `ket` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_pm_kriteria: ~12 rows (approximately)
/*!40000 ALTER TABLE `m_pm_kriteria` DISABLE KEYS */;
INSERT INTO `m_pm_kriteria` (`id`, `kode`, `kriteria`, `bobot`, `ket`) VALUES
	(1, 'K01', 'IPK', 5, 'BA'),
	(2, 'K02', 'Nilai Mata Kuliah', 4, 'BA'),
	(3, 'K03', 'Sertifikat', 3, 'BA'),
	(4, 'K04', 'Kompetensi', 5, 'TK'),
	(5, 'K05', 'Suara', 4, 'TK'),
	(6, 'K06', 'Penguasaan Materi', 3, 'TK'),
	(7, 'K07', 'Penyampaian Materi', 3, 'TM'),
	(8, 'K08', 'Sikap', 4, 'TM'),
	(9, 'K09', 'Interaksi', 3, 'TM'),
	(10, 'K10', 'Komitmen', 5, 'TM'),
	(11, 'K11', 'Konsisten', 5, 'TW'),
	(12, 'K12', 'Karakter', 3, 'TW');
/*!40000 ALTER TABLE `m_pm_kriteria` ENABLE KEYS */;

-- Dumping structure for table spk.m_pm_rank
CREATE TABLE IF NOT EXISTS `m_pm_rank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `n_administrasi` float DEFAULT NULL,
  `n_kompetensi` float DEFAULT NULL,
  `n_mengajar` float DEFAULT NULL,
  `n_wawancara` float DEFAULT NULL,
  `n_akhir` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_pm_rank: ~4 rows (approximately)
/*!40000 ALTER TABLE `m_pm_rank` DISABLE KEYS */;
INSERT INTO `m_pm_rank` (`id`, `nama`, `n_administrasi`, `n_kompetensi`, `n_mengajar`, `n_wawancara`, `n_akhir`) VALUES
	(1, 'Andi Miftahul Ilmi Fadillah', 1.36, 1.66, 2.42, 0.3, 1.7),
	(2, 'Sahrani', 1.56, 1.86, 2.42, 0.41, 1.82),
	(3, 'Ita Cahyani', 1.8, 1.72, 2.25, 0.41, 1.8),
	(4, 'Ahmad Asyraf', 2, 1.62, 2.36, 0.28, 1.86);
/*!40000 ALTER TABLE `m_pm_rank` ENABLE KEYS */;

-- Dumping structure for table spk.m_saw_kriteria
CREATE TABLE IF NOT EXISTS `m_saw_kriteria` (
  `id_kriteria` int(11) NOT NULL AUTO_INCREMENT,
  `1_ipk` varchar(50) DEFAULT NULL,
  `1_nilai_ipk` int(5) DEFAULT NULL,
  `2_matkul` varchar(50) DEFAULT NULL,
  `2_nilai_matkul` int(5) DEFAULT NULL,
  `3_sertifikat` varchar(50) DEFAULT NULL,
  `3_nilai_serifikat` int(5) DEFAULT NULL,
  `4_kompetensi` varchar(50) DEFAULT NULL,
  `4_nilai_kompetensi` int(5) DEFAULT NULL,
  `5_suara` varchar(50) DEFAULT NULL,
  `5_nilai_suara` int(5) DEFAULT NULL,
  `6_peng_materi` varchar(50) DEFAULT NULL,
  `6_nilai_peng_materi` int(5) DEFAULT NULL,
  `7_peny_materi` varchar(50) DEFAULT NULL,
  `7_nilai_peny_materi` int(5) DEFAULT NULL,
  `8_sikap` varchar(50) DEFAULT NULL,
  `8_nilai_sikap` int(5) DEFAULT NULL,
  `9_interaksi` varchar(50) DEFAULT NULL,
  `9_nilai_interaksi` int(5) DEFAULT NULL,
  `10_komitmen` varchar(50) DEFAULT NULL,
  `10_nilai_komitmen` int(5) DEFAULT NULL,
  `11_konsisten` varchar(50) DEFAULT NULL,
  `11_nilai_konsisten` int(5) DEFAULT NULL,
  `12_karakter` varchar(50) DEFAULT NULL,
  `12_nilai_karakter` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_kriteria`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_saw_kriteria: ~1 rows (approximately)
/*!40000 ALTER TABLE `m_saw_kriteria` DISABLE KEYS */;
INSERT INTO `m_saw_kriteria` (`id_kriteria`, `1_ipk`, `1_nilai_ipk`, `2_matkul`, `2_nilai_matkul`, `3_sertifikat`, `3_nilai_serifikat`, `4_kompetensi`, `4_nilai_kompetensi`, `5_suara`, `5_nilai_suara`, `6_peng_materi`, `6_nilai_peng_materi`, `7_peny_materi`, `7_nilai_peny_materi`, `8_sikap`, `8_nilai_sikap`, `9_interaksi`, `9_nilai_interaksi`, `10_komitmen`, `10_nilai_komitmen`, `11_konsisten`, `11_nilai_konsisten`, `12_karakter`, `12_nilai_karakter`) VALUES
	(1, '3.51 - 4.00', 5, 'A', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `m_saw_kriteria` ENABLE KEYS */;

-- Dumping structure for table spk.m_saw_normalisasi
CREATE TABLE IF NOT EXISTS `m_saw_normalisasi` (
  `id_normalisasi` int(11) NOT NULL AUTO_INCREMENT,
  `alternatif` varchar(100) DEFAULT NULL,
  `k1` int(2) DEFAULT NULL,
  `k2` int(2) DEFAULT NULL,
  `k3` int(2) DEFAULT NULL,
  `k4` int(2) DEFAULT NULL,
  `k5` int(2) DEFAULT NULL,
  `k6` int(2) DEFAULT NULL,
  `k7` int(2) DEFAULT NULL,
  `k8` int(2) DEFAULT NULL,
  `k9` int(2) DEFAULT NULL,
  `k10` int(2) DEFAULT NULL,
  `k11` int(2) DEFAULT NULL,
  `k12` int(2) DEFAULT NULL,
  PRIMARY KEY (`id_normalisasi`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_saw_normalisasi: ~4 rows (approximately)
/*!40000 ALTER TABLE `m_saw_normalisasi` DISABLE KEYS */;
INSERT INTO `m_saw_normalisasi` (`id_normalisasi`, `alternatif`, `k1`, `k2`, `k3`, `k4`, `k5`, `k6`, `k7`, `k8`, `k9`, `k10`, `k11`, `k12`) VALUES
	(1, 'Andi Miftahul Ilmi', 2, 5, 3, 5, 2, 4, 5, 4, 5, 4, 2, 3),
	(2, 'Sahrani', 3, 5, 3, 5, 4, 4, 5, 3, 4, 4, 5, 2),
	(3, 'Ita Cahyani', 4, 4, 3, 5, 3, 2, 3, 2, 2, 3, 5, 2),
	(4, 'Ahmad Asyraf', 5, 4, 3, 5, 2, 2, 5, 5, 2, 3, 2, 4);
/*!40000 ALTER TABLE `m_saw_normalisasi` ENABLE KEYS */;

-- Dumping structure for table spk.m_saw_normalisasi_copy
CREATE TABLE IF NOT EXISTS `m_saw_normalisasi_copy` (
  `id_normalisasi` int(11) NOT NULL AUTO_INCREMENT,
  `alternatif` varchar(100) DEFAULT NULL,
  `k1` int(2) DEFAULT NULL,
  `k2` int(2) DEFAULT NULL,
  `k3` int(2) DEFAULT NULL,
  `k4` int(2) DEFAULT NULL,
  `k5` int(2) DEFAULT NULL,
  `k6` int(2) DEFAULT NULL,
  `k7` int(2) DEFAULT NULL,
  `k8` int(2) DEFAULT NULL,
  `k9` int(2) DEFAULT NULL,
  `k10` int(2) DEFAULT NULL,
  `k11` int(2) DEFAULT NULL,
  `k12` int(2) DEFAULT NULL,
  PRIMARY KEY (`id_normalisasi`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- Dumping data for table spk.m_saw_normalisasi_copy: ~4 rows (approximately)
/*!40000 ALTER TABLE `m_saw_normalisasi_copy` DISABLE KEYS */;
INSERT INTO `m_saw_normalisasi_copy` (`id_normalisasi`, `alternatif`, `k1`, `k2`, `k3`, `k4`, `k5`, `k6`, `k7`, `k8`, `k9`, `k10`, `k11`, `k12`) VALUES
	(1, 'Andi Miftahul Ilmi', 2, 5, 3, 5, 2, 4, 5, 4, 5, 4, 2, 3),
	(2, 'Sahrani', 3, 5, 3, 5, 4, 4, 5, 3, 4, 4, 5, 2),
	(3, 'Ita Cahyani', 4, 4, 3, 5, 3, 2, 3, 2, 2, 3, 5, 2),
	(4, 'Ahmad Asyraf', 5, 4, 3, 5, 2, 2, 5, 5, 2, 3, 2, 4);
/*!40000 ALTER TABLE `m_saw_normalisasi_copy` ENABLE KEYS */;

-- Dumping structure for table spk.m_saw_rank
CREATE TABLE IF NOT EXISTS `m_saw_rank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `rank` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_saw_rank: ~4 rows (approximately)
/*!40000 ALTER TABLE `m_saw_rank` DISABLE KEYS */;
INSERT INTO `m_saw_rank` (`id`, `nama`, `rank`) VALUES
	(1, 'Andi Miftahul Ilmi', '77%'),
	(2, 'Sahrani', '83%'),
	(3, 'Ita Cahyani', '83%'),
	(4, 'Ahmad Asyraf', '86%');
/*!40000 ALTER TABLE `m_saw_rank` ENABLE KEYS */;

-- Dumping structure for table spk.m_user
CREATE TABLE IF NOT EXISTS `m_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `aktif` int(1) DEFAULT NULL,
  `nip_nim` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_user: ~7 rows (approximately)
/*!40000 ALTER TABLE `m_user` DISABLE KEYS */;
INSERT INTO `m_user` (`id`, `username`, `password`, `nama`, `role`, `status`, `role_id`, `created_at`, `updated_at`, `aktif`, `nip_nim`) VALUES
	(10, 'irul', 'e9b195132b4fe5201534844aafaab68c', 'hoirul r', 'admin', 1, 1, '2022-03-14 16:00:41', NULL, 1, '7701'),
	(11, 'kiki', '0d61130a6dd5eea85c2c5facfe1c15a7', 'Nur Rezki Rahmani', 'dosen', 1, 2, '2022-03-14 16:32:34', NULL, 1, '7702'),
	(12, 'aku', '89ccfac87d8d06db06bf3211cb2d69ed', 'Hoirul Rhojiqin', 'mahasiswa', 1, 3, '2022-03-14 17:44:14', NULL, 1, '60900114011'),
	(13, 'nia', '04a481486dd84d7c8bfdfc89d38136a6', 'Nia Nita', 'mahasiswa', 1, 3, '2022-03-28 11:47:03', NULL, 1, '60900114002'),
	(14, 'kucing', 'b65845fca59b323bd285bdcada3454c8', 'Kucing', 'mahasiswa', 1, 3, '2022-06-13 16:58:04', NULL, 1, '9090'),
	(15, 'anjing', 'a1fb7f01ffe3fc76e0b997be59ae212f', 'anjing', 'mahasiswa', 1, 3, '2022-06-13 17:01:37', NULL, 1, '3434'),
	(16, 'burung', '9061f4a93ab9de38bddf28e675732f39', 'burung', 'mahasiswa', 1, 3, '2022-06-13 17:04:00', NULL, 1, '8787');
/*!40000 ALTER TABLE `m_user` ENABLE KEYS */;

-- Dumping structure for table spk.m_user_detail
CREATE TABLE IF NOT EXISTS `m_user_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `no_hp` varchar(50) DEFAULT NULL,
  `alamat` text,
  `tentang_saya` text,
  `link_image` text,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_user_detail: ~3 rows (approximately)
/*!40000 ALTER TABLE `m_user_detail` DISABLE KEYS */;
INSERT INTO `m_user_detail` (`id`, `id_user`, `email`, `tgl_lahir`, `gender`, `no_hp`, `alamat`, `tentang_saya`, `link_image`) VALUES
	(1, 13, 'Nia@gmail.com', '1998-03-28', 'wanita', '08122211122', 'Giwa', 'Hello', NULL),
	(2, 10, 'hoirul1995@gmail.com', '1995-03-28', 'pria', '081334431144', 'Jl. Minasa Upa', 'Hobi Jalan dan Suka Motret', NULL),
	(3, 12, 'irul@gmail.com', '2022-06-13', 'pria', '2323232', 'sdsd', 'sdsd', NULL);
/*!40000 ALTER TABLE `m_user_detail` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
